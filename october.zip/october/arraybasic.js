const a = [1,3,5,2,7,8,4,10,6,9];
const position = 4;

console.log(a[6]);  // Ans : 4
console.log(a[11]); // Ans : undefined
console.log(a[a.length]); // Ans: undefined
console.log(a[a.length - 1]); // Ans: 9
console.log(a[a.length - 3]); // Ans: 10
console.log(a[position]);  // Ans : 7
console.log(a[position - 1]); // Ans : 2