let str = "Apple, Banana, Kiwi";
console.log(str.slice(7, 13));    // Ans Banana

console.log(str.substring(0,5));  // Ans Apple

console.log(str.substr());
